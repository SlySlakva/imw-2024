//Click Function (applied to box lid)
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('myBox').addEventListener('click', function() {
        window.location.href = 'box.html';
    });
}); 